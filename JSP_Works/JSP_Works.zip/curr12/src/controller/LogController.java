package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LogDAO;

@WebServlet("/log/*")
public class LogController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet() working.....");
		this.logWorks(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		System.out.println("doGet() working.....");
		this.logWorks(request, response);
	}
	
	private void logWorks(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("logWorks() working.....");
		
		String rcvUri = request.getRequestURI();
		String contextPath = request.getContextPath();
		String svlPath = request.getServletPath();
		
		String works = rcvUri.replace(contextPath +svlPath + "/", "");
		System.out.println("logWorks : " + works);
		
		String msg = "";
		String url = null;
		
		if(works.equals("logConn")){
			String id = request.getParameter("id");
			String pw = request.getParameter("pw");
			boolean result = new LogDAO().login(id, pw);
			
			if(result){
				msg = id + "님 로그인 완료";
				HttpSession session = request.getSession();
				session.setAttribute("nowLogin", id);
			}else {
				msg = "로그인 실패";
			}
		}
		
		request.setAttribute("msg",	msg);
		RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
		rd.forward(request, response);
	}
}
