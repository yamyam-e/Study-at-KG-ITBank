package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import module.JdbcConnector;

public class LogDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public LogDAO() {
		try {
			conn = JdbcConnector.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean login(String id, String pw){
		
		boolean result = false;
		
		try {
			String sql = "select * from t_log where id=? and pw=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			
			result = rs.next();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcConnector.close(conn, pstmt, rs);
		}
		return result;
	}

}
