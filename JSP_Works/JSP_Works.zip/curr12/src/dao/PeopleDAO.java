package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.PeopleDTO;
import module.JdbcConnector;

public class PeopleDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public PeopleDAO() {
		try {
			conn = JdbcConnector.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Object selectList(){
		
		ArrayList<PeopleDTO> listc = null;
		
		try {
			String sql = "select * from t_peo order by num desc";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(listc == null) listc = new ArrayList<>();
				PeopleDTO dto = new PeopleDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setAge(rs.getInt("age"));
				listc.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcConnector.close(conn, pstmt, rs);
		}
		return listc;
	}
}
